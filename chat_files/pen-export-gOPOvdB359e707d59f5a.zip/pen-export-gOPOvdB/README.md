# 3D First Person Art Gallery - No Javascript!

A Pen created on CodePen.io. Original URL: [https://codepen.io/ivorjetski/pen/gOPOvdB](https://codepen.io/ivorjetski/pen/gOPOvdB).

A CSS art gallery you can look around. Images of pure CSS art, but unfortunately peoples computer would explode if I didn't use images. Everything else is pure CSS though. 

+ There are a few Easter Eggs scattered about.

A very short video of some of the coding:
https://youtu.be/4s0PT709Ia0. 
Subscribe for more or follow me to say hi:
https://www.instagram.com/ivorjetski
https://twitter.com/ivorjetski